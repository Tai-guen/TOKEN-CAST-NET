# TOKEN CAST NET 🎯
**Website cá nhân của Ahaibi – Chuyên tư vấn Tài chính & Crypto**

## 📁 Cấu trúc file
```
tokencastnet/
├── index.html      ← Trang chủ
├── blog.html       ← Blog / bài viết
├── dashboard.html  ← Dashboard giá Crypto live
├── style.css       ← Toàn bộ styles
├── main.js         ← JavaScript chung
├── vercel.json     ← Cấu hình Vercel
└── README.md
```

## 🚀 Deploy lên Vercel (3 cách)

### Cách 1: Kéo thả (Dễ nhất)
1. Truy cập [vercel.com](https://vercel.com) → Đăng nhập
2. Nhấn **"Add New Project"**
3. Kéo toàn bộ thư mục `tokencastnet` vào vùng upload
4. Nhấn **Deploy** → Xong! ✅

### Cách 2: Qua GitHub
1. Tạo repo mới trên GitHub
2. Upload toàn bộ file vào repo
3. Vào Vercel → **Import Git Repository**
4. Chọn repo vừa tạo → Deploy

### Cách 3: Vercel CLI
```bash
npm i -g vercel
cd tokencastnet
vercel
# Làm theo hướng dẫn terminal
```

## ✨ Tính năng
- **Trang chủ**: Hero section, ticker giá, giới thiệu, blog cards, sản phẩm, contact
- **Blog**: Lưới bài viết có thể lọc theo danh mục + tìm kiếm
- **Dashboard**: Giá crypto live từ CoinGecko, Fear & Greed Index, Trending, AI signals
- **Dark Mode**: Phong cách metaverse tối giản
- **Responsive**: Mobile-first design

## 🔧 Tùy chỉnh
- Thay link mạng xã hội: Tìm `href="#"` trong HTML và điền URL thực
- Thêm bài viết blog: Thêm object vào mảng `posts[]` trong `blog.html`
- Đổi màu sắc: Chỉnh CSS variables trong `:root {}` trong `style.css`

## 📡 API sử dụng
- [CoinGecko API](https://api.coingecko.com) – Giá coin (miễn phí, giới hạn 30 req/phút)
- [Alternative.me Fear & Greed](https://api.alternative.me/fng/) – Chỉ số tâm lý thị trường

## ⚠️ Lưu ý
Nội dung trên website chỉ mang tính tham khảo, không phải lời khuyên đầu tư tài chính.
